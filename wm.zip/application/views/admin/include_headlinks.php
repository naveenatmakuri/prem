<!-- CSS ============== -->

<link rel="stylesheet" href="<?=base_url()?>css/style.css">
<link rel="stylesheet" href="<?=base_url()?>css/colors/main.css" id="colors">
<link rel="stylesheet" href="<?=base_url()?>css/gal.css">
<link rel="stylesheet" href="<?=base_url()?>css/newstyles.css">
<script type="text/javascript" src="<?=base_url()?>scripts/jquery.min.js"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/sweetalert.css">

<style>
.copyrights {
  text-align: right; border-top:1px solid #bcbcbc; padding-top:5px; padding-right: 12px; background-color:#333; color:#eef;
}

</style>
