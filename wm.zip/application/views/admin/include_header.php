 <!-- Wrapper -->
 <div id="wrapper">


  <header style="background:#333 url('<?=base_url()?>img/menubg.jpg') repeat; background-attachment:fixed;">
      <div class="container">
              <div class="hboxdiv">
                <div class="hdivc">
     <a href="<?=base_url()?>admin/dashboard" >
     <img src="<?=base_url()?>img/logo.png" alt="<?=$this->user_model->sitename?>" class="img-responsive" style="max-height: 70px;"> 
    </a>
                </div>
                <div class="hdivc">

            <div class="user-menu">
              <a href="<?=base_url()?>admin/dashboard" >
              <div class="user-name" style="color: #fff;" ><i class="list-box-icon fa fa-user"></i> Role: &nbsp; <b> Admin</b></div>
            </a>
            </div>

                </div>
              </div>
      </div>
  </header>


   <div class="clearfix"></div>
   <!-- Header Container / End -->

