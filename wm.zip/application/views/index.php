<?php 
header("location: admin/");
 ?>